using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.UIA2;
using FlaUI.UIA3;

namespace AITestCaseStudio.DesktopEngine
{
    /// <summary>
    /// TestData/app.json — which Windows application the generated tests drive.
    /// Written by AITestCaseStudio from the intake (never by hand).
    /// </summary>
    public sealed class AppConfig
    {
        [JsonPropertyName("app_path")] public string AppPath { get; set; } = "";
        [JsonPropertyName("app_args")] public string AppArgs { get; set; } = "";
        [JsonPropertyName("working_dir")] public string WorkingDir { get; set; } = "";
        /// <summary>"uia3" (default; WinForms/WPF/modern Win32) or "uia2" (often better for VB6/legacy Win32).</summary>
        [JsonPropertyName("uia")] public string Uia { get; set; } = "uia3";
        /// <summary>Seconds to wait for the main window after launch.</summary>
        [JsonPropertyName("startup_timeout_s")] public int StartupTimeoutS { get; set; } = 60;

        public static AppConfig Load(string path)
        {
            var cfg = JsonSerializer.Deserialize<AppConfig>(File.ReadAllText(path))
                      ?? throw new InvalidOperationException($"Empty app config: {path}");
            if (string.IsNullOrWhiteSpace(cfg.AppPath))
                throw new InvalidOperationException($"app_path is missing in {path}");
            return cfg;
        }
    }

    /// <summary>
    /// The application under test: launched once per test case, every top-level
    /// window of its process (main window, modal dialogs, message boxes) searchable.
    /// </summary>
    public sealed class DesktopApp : IDisposable
    {
        public Application App { get; }
        public AutomationBase Automation { get; }
        public AppConfig Config { get; }

        private DesktopApp(Application app, AutomationBase automation, AppConfig config)
        {
            App = app;
            Automation = automation;
            Config = config;
        }

        public static DesktopApp Launch(AppConfig config)
        {
            if (!File.Exists(config.AppPath))
                throw new FileNotFoundException($"Application not found: {config.AppPath}");
            var psi = new ProcessStartInfo(config.AppPath, config.AppArgs ?? "")
            {
                WorkingDirectory = string.IsNullOrWhiteSpace(config.WorkingDir)
                    ? Path.GetDirectoryName(config.AppPath)!
                    : config.WorkingDir,
                UseShellExecute = false,
            };
            AutomationBase automation = string.Equals(config.Uia, "uia2", StringComparison.OrdinalIgnoreCase)
                ? new UIA2Automation()
                : new UIA3Automation();
            Console.WriteLine($"[app] launching {config.AppPath} {config.AppArgs} (automation={config.Uia})");
            var app = Application.Launch(psi);
            app.WaitWhileMainHandleIsMissing(TimeSpan.FromSeconds(config.StartupTimeoutS));
            var desktopApp = new DesktopApp(app, automation, config);
            var main = desktopApp.MainWindow();
            Console.WriteLine($"[app] main window: '{main?.Title}' (pid {app.ProcessId})");
            return desktopApp;
        }

        public Window? MainWindow()
        {
            try { return App.GetMainWindow(Automation, TimeSpan.FromSeconds(Config.StartupTimeoutS)); }
            catch { return null; }
        }

        /// <summary>
        /// Every window of the process, the dialog on top first: a dialog is where the
        /// next control lives, and the window behind it is not usable. Modal dialogs
        /// (WinForms ShowDialog, message boxes) are exposed by UI Automation as CHILDREN
        /// of their owner window, not as top-level windows, so they are collected from
        /// each window's ModalWindows (nested dialogs included, deepest first).
        /// </summary>
        public IReadOnlyList<Window> Windows()
        {
            Window[] tops;
            try { tops = App.GetAllTopLevelWindows(Automation); }
            catch { return Array.Empty<Window>(); }
            var result = new List<Window>();
            foreach (var top in tops.OrderByDescending(SafeIsModal))
            {
                AddModals(top, result, depth: 0);
                result.Add(top);
            }
            return result;
        }

        private static void AddModals(Window window, List<Window> result, int depth)
        {
            if (depth > 5) return;
            Window[] modals;
            try { modals = window.ModalWindows; } catch { return; }
            foreach (var modal in modals)
            {
                AddModals(modal, result, depth + 1);
                result.Add(modal);
            }
        }

        private static bool SafeIsModal(Window w)
        {
            try { return w.IsModal; } catch { return false; }
        }

        public bool HasExited
        {
            get { try { return App.HasExited; } catch { return true; } }
        }

        public void Close()
        {
            try
            {
                if (App.HasExited) return;
                App.Close();
                for (int i = 0; i < 20 && !App.HasExited; i++) Thread.Sleep(250);
                if (!App.HasExited) App.Kill();
            }
            catch { /* already gone */ }
        }

        public void Dispose()
        {
            Close();
            App.Dispose();
            Automation.Dispose();
        }
    }
}
