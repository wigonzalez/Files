using System.Diagnostics;
using System.Net;
using System.Text;
using FlaUI.Core.Capturing;

namespace AITestCaseStudio.DesktopEngine
{
    public sealed class StepFailedException : Exception
    {
        public StepFailedException(string message, Exception? inner = null) : base(message, inner) { }
    }

    public sealed class StepRecord
    {
        public int Index { get; init; }
        public string Name { get; init; } = "";
        public string Status { get; set; } = "running";
        public long Ms { get; set; }
        public string Error { get; set; } = "";
        public string Screenshot { get; set; } = "";
    }

    /// <summary>
    /// Runs the steps of one desktop test case in order. Every step prints the same
    /// machine markers as the web engine (##STEP## idx= status=start|pass|fail), so the
    /// AITestCaseStudio GUI paints its grid and the healer reads the same evidence:
    ///   FAIL step='…' error=…           the failing step and why
    ///   SCREENSHOT: …png                the screen at the moment of failure
    ///   [uia] near-miss candidates …    what was on screen (from DesktopLocators)
    ///   HTML report: …                  the run report
    /// The first failing step stops the test case (later steps depend on it).
    /// </summary>
    public sealed class DesktopStepRunner
    {
        private readonly DesktopApp _app;
        private readonly string _testCaseId;
        private readonly string _reportDir;
        private readonly List<StepRecord> _steps = new();
        private int _index;

        /// <summary>Max time to wait for a step's expected anchor.</summary>
        public int AnchorTimeoutMs { get; set; } = 15000;

        public DesktopStepRunner(DesktopApp app, string testCaseId, string reportsRoot)
        {
            _app = app;
            _testCaseId = testCaseId;
            _reportDir = Path.Combine(reportsRoot, $"{testCaseId}_{DateTime.Now:yyyyMMdd_HHmmss}");
            Directory.CreateDirectory(_reportDir);
        }

        public IReadOnlyList<StepRecord> Steps => _steps;
        public bool Passed => _steps.Count > 0 && _steps.All(s => s.Status == "pass");

        /// <param name="anchors">Positive anchors are ORed (any one visible = verified); an anchor
        /// starting with '!' must DISAPPEAR (e.g. a closed dialog's title).</param>
        public async Task RunAsync(string name, Func<Task> action, string[]? anchors = null, int waitMs = 0)
        {
            var record = new StepRecord { Index = ++_index, Name = name };
            _steps.Add(record);
            var clean = name.Replace("\r", " ").Replace("\n", " ");
            Console.WriteLine($"##STEP## idx={record.Index} status=start name={clean}");
            Console.WriteLine($"[step {record.Index}] {clean}");
            var sw = Stopwatch.StartNew();
            try
            {
                if (_app.HasExited) throw new StepFailedException("the application is no longer running");
                await action();
                if (waitMs > 0) await Task.Delay(waitMs);
                WaitForAnchors(anchors);
                record.Status = "pass";
                record.Ms = sw.ElapsedMilliseconds;
                Console.WriteLine($"##STEP## idx={record.Index} status=pass name={clean}");
            }
            catch (Exception ex)
            {
                record.Status = "fail";
                record.Ms = sw.ElapsedMilliseconds;
                record.Error = (ex.Message ?? ex.GetType().Name).Replace("\r", " ").Replace("\n", " ");
                record.Screenshot = CaptureScreen(record.Index);
                Console.WriteLine($"FAIL step='{clean}' error={record.Error}");
                if (record.Screenshot.Length > 0) Console.WriteLine($"SCREENSHOT: {record.Screenshot}");
                if (ex is not ElementNotFoundException && !_app.HasExited) DesktopLocators.DumpCandidates(_app);
                Console.WriteLine($"##STEP## idx={record.Index} status=fail name={clean}");
                throw new StepFailedException(record.Error, ex);
            }
        }

        private void WaitForAnchors(string[]? anchors)
        {
            var list = (anchors ?? Array.Empty<string>()).Where(a => !string.IsNullOrWhiteSpace(a)).ToList();
            if (list.Count == 0) return;
            var negatives = list.Where(a => a.StartsWith('!')).Select(a => a[1..]).ToList();
            var positives = list.Where(a => !a.StartsWith('!')).ToList();
            var deadline = DateTime.UtcNow.AddMilliseconds(AnchorTimeoutMs);
            while (true)
            {
                bool positiveOk = positives.Count == 0 || positives.Any(a => DesktopLocators.TextVisible(_app, a));
                bool negativeOk = negatives.All(a => !DesktopLocators.TextVisible(_app, a));
                if (positiveOk && negativeOk)
                {
                    Console.WriteLine($"[anchor] verified: {string.Join(" | ", list)}");
                    return;
                }
                if (DateTime.UtcNow > deadline)
                    throw new StepFailedException(!positiveOk
                        ? $"expected anchor not visible after {AnchorTimeoutMs} ms: {string.Join(" | ", positives)}"
                        : $"expected to disappear but still visible after {AnchorTimeoutMs} ms: {string.Join(" | ", negatives)}");
                Thread.Sleep(300);
            }
        }

        private string CaptureScreen(int index)
        {
            try
            {
                var file = Path.Combine(_reportDir, $"fail_step{index:00}.png");
                Capture.Screen().ToFile(file);
                return file;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[forensics] screenshot failed: {ex.Message}");
                return "";
            }
        }

        /// <summary>Writes the HTML report and prints its path; returns it.</summary>
        public string WriteReport()
        {
            var html = new StringBuilder();
            html.Append("<!doctype html><html><head><meta charset='utf-8'><title>")
                .Append(WebUtility.HtmlEncode(_testCaseId)).Append("</title><style>")
                .Append("body{font-family:Segoe UI,Arial;margin:24px}table{border-collapse:collapse}")
                .Append("td,th{border:1px solid #ccc;padding:4px 8px;text-align:left}")
                .Append(".pass{background:#e6f4ea}.fail{background:#fce8e6}</style></head><body>")
                .Append("<h2>").Append(WebUtility.HtmlEncode(_testCaseId)).Append(Passed ? " — PASSED" : " — FAILED").Append("</h2>")
                .Append("<p>").Append(WebUtility.HtmlEncode(_app.Config.AppPath)).Append("</p>")
                .Append("<table><tr><th>#</th><th>Step</th><th>Status</th><th>ms</th><th>Error</th></tr>");
            foreach (var s in _steps)
            {
                html.Append($"<tr class='{s.Status}'><td>{s.Index}</td><td>{WebUtility.HtmlEncode(s.Name)}</td>")
                    .Append($"<td>{s.Status}</td><td>{s.Ms}</td><td>{WebUtility.HtmlEncode(s.Error)}");
                if (s.Screenshot.Length > 0)
                    html.Append($"<br><img src='{WebUtility.HtmlEncode(Path.GetFileName(s.Screenshot))}' style='max-width:900px'>");
                html.Append("</td></tr>");
            }
            html.Append("</table></body></html>");
            var path = Path.Combine(_reportDir, "report.html");
            File.WriteAllText(path, html.ToString());
            Console.WriteLine($"HTML report: {path}");
            return path;
        }
    }

    /// <summary>TestData CSVs (header row + data rows), the same files the web projects use.</summary>
    public static class TestData
    {
        public static List<Dictionary<string, string>> ReadCsv(string path)
        {
            var rows = new List<Dictionary<string, string>>();
            if (!File.Exists(path)) return rows;
            var lines = File.ReadAllLines(path).Where(l => l.Trim().Length > 0).ToList();
            if (lines.Count == 0) return rows;
            var header = SplitCsv(lines[0]);
            foreach (var line in lines.Skip(1))
            {
                var cells = SplitCsv(line);
                var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < header.Count; i++) row[header[i].Trim()] = i < cells.Count ? cells[i] : "";
                rows.Add(row);
            }
            return rows;
        }

        private static List<string> SplitCsv(string line)
        {
            var cells = new List<string>();
            var current = new StringBuilder();
            bool quoted = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (quoted && i + 1 < line.Length && line[i + 1] == '"') { current.Append('"'); i++; }
                    else quoted = !quoted;
                }
                else if (c == ',' && !quoted) { cells.Add(current.ToString()); current.Clear(); }
                else current.Append(c);
            }
            cells.Add(current.ToString());
            return cells;
        }

        /// <summary>Replaces {placeholder} with the row's value (left as is when the column is missing).</summary>
        public static string Resolve(string text, IReadOnlyDictionary<string, string> row)
        {
            foreach (var kv in row) text = text.Replace("{" + kv.Key + "}", kv.Value, StringComparison.OrdinalIgnoreCase);
            return text;
        }
    }
}
