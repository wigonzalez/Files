using System.Text.Json;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Definitions;
using FlaUI.Core.Input;
using FlaUI.Core.WindowsAPI;

namespace AITestCaseStudio.DesktopEngine
{
    /// <summary>
    /// Desktop selector grammar (UI Automation), parts joined by ';':
    ///   id=txtUserName          AutomationId (WinForms: the control's Name)
    ///   name=OK                 Name / visible caption, exact (case-insensitive, '&amp;' ignored)
    ///   name^=001-              Name starts with
    ///   name*=Report            Name contains
    ///   type=TreeItem           ControlType (Button, Edit, TreeItem, ListItem, DataItem,
    ///                           MenuItem, ComboBox, CheckBox, RadioButton, TabItem, Text, ...)
    ///   window=Employer Search  only inside the top-level window whose title contains this
    ///   index=1                 the Nth match (0-based) when several qualify
    /// A selector without '=' is a Name: exact first, then contains.
    /// </summary>
    public sealed class Selector
    {
        public string? Id, Name, NamePrefix, NameContains, Type, Window;
        public int Index;
        public string Raw = "";

        public static Selector Parse(string raw)
        {
            var s = new Selector { Raw = raw };
            if (!raw.Contains('='))
            {
                s.Name = raw.Trim().Trim('\'', '"');
                return s;
            }
            foreach (var part in raw.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                int eq = part.IndexOf('=');
                if (eq <= 0) continue;
                var key = part[..eq].Trim().ToLowerInvariant();
                var value = part[(eq + 1)..].Trim().Trim('\'', '"');
                switch (key)
                {
                    case "id": s.Id = value; break;
                    case "name": s.Name = value; break;
                    case "name^": s.NamePrefix = value; break;
                    case "name*": s.NameContains = value; break;
                    case "type": s.Type = value; break;
                    case "window": s.Window = value; break;
                    case "index": int.TryParse(value, out s.Index); break;
                }
            }
            return s;
        }

        public override string ToString() => Raw;
    }

    public static class DesktopLocators
    {
        public static int DefaultTimeoutMs = 15000;

        internal static string Clean(string? text)
            => (text ?? "").Replace("&", "").Trim();

        private static bool NameMatches(AutomationElement e, Selector s, bool exactOnly)
        {
            var name = Clean(SafeName(e));
            if (s.Name != null)
            {
                var wanted = Clean(s.Name);
                if (string.Equals(name, wanted, StringComparison.OrdinalIgnoreCase)) return true;
                if (exactOnly) return false;
                return name.Contains(wanted, StringComparison.OrdinalIgnoreCase);
            }
            if (s.NamePrefix != null && !name.StartsWith(Clean(s.NamePrefix), StringComparison.OrdinalIgnoreCase)) return false;
            if (s.NameContains != null && !name.Contains(Clean(s.NameContains), StringComparison.OrdinalIgnoreCase)) return false;
            return true;
        }

        internal static string SafeName(AutomationElement e) { try { return e.Name ?? ""; } catch { return ""; } }
        internal static string SafeId(AutomationElement e) { try { return e.AutomationId ?? ""; } catch { return ""; } }
        internal static string SafeType(AutomationElement e) { try { return e.ControlType.ToString(); } catch { return "?"; } }
        private static bool SafeUsable(AutomationElement e)
        {
            try { return e.IsEnabled && !e.IsOffscreen; } catch { return false; }
        }

        private static IEnumerable<AutomationElement> Candidates(DesktopApp app, Selector s)
        {
            foreach (var window in app.Windows())
            {
                if (s.Window != null && !Clean(window.Title).Contains(Clean(s.Window), StringComparison.OrdinalIgnoreCase))
                    continue;
                AutomationElement[] all;
                try
                {
                    var cf = window.ConditionFactory;
                    if (s.Id != null) all = window.FindAllDescendants(cf.ByAutomationId(s.Id));
                    else if (s.Type != null && Enum.TryParse<ControlType>(s.Type, true, out var ct))
                        all = window.FindAllDescendants(cf.ByControlType(ct));
                    else all = window.FindAllDescendants();
                }
                catch { continue; }
                foreach (var e in all) yield return e;
                // The window itself can be the target (e.g. window=Report;type=Window)
                yield return window;
            }
        }

        private static List<AutomationElement> Matches(DesktopApp app, Selector s)
        {
            bool TypeOk(AutomationElement e) => s.Type == null
                || string.Equals(SafeType(e), s.Type, StringComparison.OrdinalIgnoreCase);
            bool IdOk(AutomationElement e) => s.Id == null || string.Equals(SafeId(e), s.Id, StringComparison.Ordinal);
            var pool = Candidates(app, s).Where(e => TypeOk(e) && IdOk(e)).ToList();
            // Exact name beats contains: "OK" must not resolve to "OK to all".
            var exact = pool.Where(e => NameMatches(e, s, exactOnly: true)).ToList();
            var found = exact.Count > 0 ? exact : pool.Where(e => NameMatches(e, s, exactOnly: false)).ToList();
            // Usable (enabled + on screen) first, keeping document order.
            return found.Where(SafeUsable).Concat(found.Where(e => !SafeUsable(e))).ToList();
        }

        /// <summary>Wait until the selector resolves; throws with the near-miss candidates printed.</summary>
        public static AutomationElement Find(DesktopApp app, string selector, int timeoutMs = 0)
        {
            var s = Selector.Parse(selector);
            var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs > 0 ? timeoutMs : DefaultTimeoutMs);
            while (true)
            {
                var found = Matches(app, s);
                if (found.Count > s.Index)
                {
                    var el = found[s.Index];
                    Console.WriteLine($"##RESOLVED_SELECTOR## {selector} => {Describe(el)}");
                    return el;
                }
                if (DateTime.UtcNow > deadline || app.HasExited)
                {
                    DumpCandidates(app, s);
                    throw new ElementNotFoundException($"No element for selector '{selector}' " +
                        (app.HasExited ? "(the application closed)" : $"after {(timeoutMs > 0 ? timeoutMs : DefaultTimeoutMs)} ms"));
                }
                Thread.Sleep(250);
            }
        }

        public static string Describe(AutomationElement e)
            => $"[{SafeType(e)}] id='{SafeId(e)}' name='{SafeName(e)}'";

        /// <summary>Real mouse click (tree nodes and legacy controls react to it), invoke as fallback.</summary>
        public static void Click(AutomationElement el, bool doubleClick = false)
        {
            try { if (el.Patterns.ScrollItem.IsSupported) el.Patterns.ScrollItem.Pattern.ScrollIntoView(); } catch { }
            try
            {
                if (doubleClick) el.DoubleClick(moveMouse: true);
                else el.Click(moveMouse: true);
                return;
            }
            catch (Exception clickError)
            {
                if (!doubleClick && el.Patterns.Invoke.IsSupported)
                {
                    Console.WriteLine($"[locator] mouse click failed ({clickError.GetType().Name}) — using Invoke");
                    el.Patterns.Invoke.Pattern.Invoke();
                    return;
                }
                throw;
            }
        }

        /// <summary>Type into a field: keyboard first (fires the app's own events), value pattern as fallback.</summary>
        public static void Type(AutomationElement el, string text)
        {
            if (string.Equals(SafeType(el), "ComboBox", StringComparison.OrdinalIgnoreCase))
            {
                var combo = el.AsComboBox();
                if (!combo.IsEditable)
                {
                    combo.Select(text);
                    return;
                }
            }
            el.Focus();
            try { el.Click(moveMouse: true); } catch { }
            Keyboard.TypeSimultaneously(VirtualKeyShort.CONTROL, VirtualKeyShort.KEY_A);
            Keyboard.Type(VirtualKeyShort.DELETE);
            Keyboard.Type(text);
            Thread.Sleep(150);
            try
            {
                if (el.Patterns.Value.IsSupported)
                {
                    var value = el.Patterns.Value.Pattern;
                    if (!string.Equals(value.Value.Value ?? "", text, StringComparison.Ordinal) && !value.IsReadOnly.Value)
                    {
                        Console.WriteLine("[locator] typed text did not land — setting the value directly");
                        value.SetValue(text);
                    }
                }
            }
            catch { /* value not readable: keyboard input stands */ }
        }

        /// <summary>Type into whatever has the keyboard focus (a type step without a selector).</summary>
        public static void TypeFocused(string text)
        {
            Keyboard.Type(text);
            Thread.Sleep(150);
        }

        private static readonly Dictionary<string, VirtualKeyShort> KeyMap = new(StringComparer.OrdinalIgnoreCase)
        {
            ["Enter"] = VirtualKeyShort.ENTER, ["Return"] = VirtualKeyShort.ENTER, ["Tab"] = VirtualKeyShort.TAB,
            ["Escape"] = VirtualKeyShort.ESCAPE, ["Esc"] = VirtualKeyShort.ESCAPE, ["Space"] = VirtualKeyShort.SPACE,
            ["Backspace"] = VirtualKeyShort.BACK, ["Delete"] = VirtualKeyShort.DELETE, ["Insert"] = VirtualKeyShort.INSERT,
            ["Home"] = VirtualKeyShort.HOME, ["End"] = VirtualKeyShort.END,
            ["PageUp"] = VirtualKeyShort.PRIOR, ["PageDown"] = VirtualKeyShort.NEXT,
            ["ArrowUp"] = VirtualKeyShort.UP, ["Up"] = VirtualKeyShort.UP, ["ArrowDown"] = VirtualKeyShort.DOWN,
            ["Down"] = VirtualKeyShort.DOWN, ["ArrowLeft"] = VirtualKeyShort.LEFT, ["Left"] = VirtualKeyShort.LEFT,
            ["ArrowRight"] = VirtualKeyShort.RIGHT, ["Right"] = VirtualKeyShort.RIGHT,
            ["Ctrl"] = VirtualKeyShort.CONTROL, ["Control"] = VirtualKeyShort.CONTROL,
            ["Alt"] = VirtualKeyShort.ALT, ["Shift"] = VirtualKeyShort.SHIFT,
        };

        public static VirtualKeyShort ParseKey(string name)
        {
            if (KeyMap.TryGetValue(name, out var k)) return k;
            if (name.Length == 1 && char.IsLetterOrDigit(name[0]))
                return Enum.Parse<VirtualKeyShort>("KEY_" + char.ToUpperInvariant(name[0]));
            if (name.Length >= 2 && (name[0] == 'F' || name[0] == 'f') && int.TryParse(name[1..], out var f) && f is >= 1 and <= 24)
                return Enum.Parse<VirtualKeyShort>("F" + f);
            throw new ArgumentException($"Unknown key '{name}'");
        }

        /// <summary>One key, or a chord when several are given (e.g. Ctrl+S).</summary>
        public static void Press(params string[] keys)
        {
            var codes = keys.Select(ParseKey).ToArray();
            if (codes.Length == 1) Keyboard.Type(codes[0]);
            else Keyboard.TypeSimultaneously(codes);
        }

        /// <summary>True when some window of the app shows the text (element name or window title).</summary>
        public static bool TextVisible(DesktopApp app, string text)
        {
            var wanted = Clean(text);
            foreach (var w in app.Windows())
            {
                try
                {
                    if (Clean(w.Title).Contains(wanted, StringComparison.OrdinalIgnoreCase)) return true;
                    foreach (var e in w.FindAllDescendants())
                    {
                        if (Clean(SafeName(e)).Contains(wanted, StringComparison.OrdinalIgnoreCase)) return true;
                        try
                        {
                            if (e.Patterns.Value.IsSupported
                                && Clean(e.Patterns.Value.Pattern.Value.Value).Contains(wanted, StringComparison.OrdinalIgnoreCase))
                                return true;
                        }
                        catch { }
                    }
                }
                catch { }
            }
            return false;
        }

        /// <summary>
        /// Printed when a selector does not resolve: what IS on screen (type, id, name),
        /// the evidence the healer uses to pick the right control.
        /// </summary>
        public static void DumpCandidates(DesktopApp app, Selector? s = null, int max = 80)
        {
            var rows = new List<object>();
            foreach (var w in app.Windows())
            {
                rows.Add(new { window = SafeName(w), type = "Window", id = SafeId(w), name = SafeName(w) });
                AutomationElement[] all;
                try { all = w.FindAllDescendants(); } catch { continue; }
                foreach (var e in all)
                {
                    var name = SafeName(e);
                    var id = SafeId(e);
                    if (name.Length == 0 && id.Length == 0) continue;
                    rows.Add(new { window = SafeName(w), type = SafeType(e), id, name });
                    if (rows.Count >= max) break;
                }
                if (rows.Count >= max) break;
            }
            Console.WriteLine($"[uia] near-miss candidates for '{s?.Raw}': {JsonSerializer.Serialize(rows)}");
        }
    }

    public sealed class ElementNotFoundException : Exception
    {
        public ElementNotFoundException(string message) : base(message) { }
    }
}
